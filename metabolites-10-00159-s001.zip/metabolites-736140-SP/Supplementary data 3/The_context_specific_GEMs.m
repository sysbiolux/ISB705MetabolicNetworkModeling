
initCobraToolbox(false) %don't update the toolbox

changeCobraSolver ('gurobi', 'all');

%path of AraGEM filename
file = 'AraGEMconstraintFree.xml';

%read model
model = readCbModel(file);

%path of transcriptome data
T = readtable('GSE65046_mean.csv');

% set model objective function_Biomass production

modelConstrained = model;
modelConstrained.c = 0*modelConstrained.c;
modelConstrained = changeObjective(modelConstrained, 'BIO_L', 1);


% Extraction model base at quantile 0.83 mimic reported biomass and collect info of active metabolites and active reactions

d = 1;
summaryT = table;
for c = 7:33
    i = T.Properties.VariableNames{c};
    
    %calculate cut-off expression threshold at percentile 83
    sorti = sort(T.(i));
    q = sorti(ceil(0.83*(length(sort(sorti))))); 
    
    %mapping gene of expression data to model 
    expressionData = table(T.ORF,T.(i),'VariableNames',{'gene','value'}); 
    [expressionRxns parsedGPR] = mapExpressionToReactions(model, expressionData); 
    
    %tailor model using GIMME
    tissueModel = GIMME(modelConstrained, expressionRxns, q); 
        
    %FBA with  maximization of biomass
    solution = optimizeCbModel(tissueModel,'max', 1e-6); 

    
    %Table of summary number of the context-specific GEMs
    x = table({i}, length(tissueModel.mets),length(tissueModel.rxns),solution.f);
    summaryT = [summaryT; x]; 
    
    %construct data structure for mets, rxns details of extracted GEMs
    summaryTissueModel(d).model = tissueModel;
    summaryTissueModel(d).model.modelID = i;
    summaryTissueModel(d).name = i;
    summaryTissueModel(d).mets = tissueModel.mets;
    summaryTissueModel(d).rxns = tissueModel.rxns;
    summaryTissueModel(d).biomassFBA = solution.f;
    summaryTissueModel(d).flux = solution.x;
    summaryTissueModel(d).solution = solution;
    
    i
    writeCbModel(tissueModel, 'fileName', i,'format', 'sbml');
    
    d = d + 1;
    end
    
%add property name    
summaryT.Properties.VariableNames ={'condition','mets','rxns','FBA'}; 



summaryT


